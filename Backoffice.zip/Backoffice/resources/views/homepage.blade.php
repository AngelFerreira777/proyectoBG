<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="icon" href="../img/Icon.png">
    <title>E.L.S - Efficient Logistic Software</title>
</head>
<body>
    <label><a href="/Backoffice">Backoffice de Administración</a></label>
    <br>
    <label><a href="/AppAlmacenes">Aplicacion de Almacén</a></label>
</body>
</html>