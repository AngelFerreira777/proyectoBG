<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>E.L.S - Almacén</title>
    <link rel="icon" href="../img/Icon.png">
</head>
<body>
    <label><a href="/AppAlmacenes/Paquetes">Paquetes</a></label>
    <br>
    <label><a href="/AppAlmacenes/Lotes">Lotes</a></label>
</body>
</html>