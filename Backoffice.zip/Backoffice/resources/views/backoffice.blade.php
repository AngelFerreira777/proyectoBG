<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="icon" href="../img/Icon.png">
    <title>E.L.S - Backoffice</title>
</head>
<body>
    <label><a href="/Backoffice/Usuarios">Usuarios del Sistema</a></label>
    <br><br>
    <label><a href="/Backoffice/Almacenes">Almacenes de 'Quick Carry'</a></label>
</body>
</html>