Primera entrega Programación Web

Usuarios y claves del sistema:

Documento de Identidad: 54870863
<br>
Nombre: JAI
<br>
Apellido: TECHNOLOGY
<br>
Email: bgproyectojaitechnology@gmail.com
<br>
Contraseña: JaiTechnology2023
<br>
Telefono: 095032752
<br>
Dirección: Av bolivia 2551
<br>
Rol: Usuario Común