<?php

namespace Tests\Feature;

use Illuminate\Foundation\Testing\RefreshDatabase;
use Illuminate\Foundation\Testing\WithFaker;

use Tests\TestCase;

use Illuminate\Support\Facades\Artisan;
use Illuminate\Support\Facades\Http;

use App\Models\Usuario;

class UsuarioTest extends TestCase
{
    public function test_EliminarUnoQueNoExiste()
    {
        $response = $this->delete('/api/v1/Backoffice/Usuarios/62562818');
        $response->assertStatus(404); 
    }
    
    public function test_EliminarUnoQueExiste()
    {
        $response = $this->delete('/api/v1/Backoffice/Usuarios/54870863');
        $response->assertStatus(200);
        $response->assertJsonFragment([
            "mensaje" => "El Usuario con la cedula 54870863 ha sido eliminado."
        ]);
        $this->assertDatabaseMissing("usuarios",[
            "docDeIdentidad" => 54870863,
            "deleted_at" => null
        ]);

        Usuario::withTrashed()->where("docDeIdentidad", 54870863)->restore();
    }

    public function test_ModificarUnoQueNoExiste()
    {
        $datosAInsertar = [
            "nombre" => "Gaston",
            "telefono" => "096321456",
            "direccion" => "Av. 404"
        ];

        $response = $this->put('/api/v1/Backoffice/Usuarios/62562818', $datosAInsertar);
        $response->assertStatus(404); 
    }

    public function test_ModificarUnoQueExiste()
    {
        $datosAInsertar = [
            "nombre" => "Angel",
            "telefono" => "568243598",
            "direccion" => "Av 207"
        ];

        $response = $this->put('/api/v1/Backoffice/Usuarios/54870863', $datosAInsertar);

        $response->assertStatus(200);
        $response->assertJsonFragment([
            "mensaje" => "El Usuario con la cedula 54870863 ha sido modificado."
        ]);
    }

    public function test_InsertarSinNada()
    {
        $response = $this->post('/api/v1/Usuarios/Crear');
        $response->assertStatus(403); 
    }

    public function test_Insertar()
    {
        $datosAInsertar = [
            "documentoDeIdentidad" => "54983459",
            "nombre" => "Joaquin",
            "apellido" => "Suarez",
            "contrasenia" => "Gordo2023",
            "contrasenia_confirmation" => "Gordo2023",
            "telefono" => "095032752",
            "direccion" => "Av 501",
            "email" => "Suarez@gmail.com"
        ];

        $response = $this->post('/api/v1/Usuarios/Crear', $datosAInsertar);

        $response->assertStatus(200);
        $response->assertJsonFragment([
            "mensaje" => "Usuario creado correctamente."
        ]);

        Usuario::where("docDeIdentidad", 54983459)->delete();
    }

    public function test_InsertarAdministrador()
    {
        $datosAInsertar = [
            "documentoDeIdentidad" => "45983459",
            "nombre" => "Alma",
            "apellido" => "Marcela",
            "contrasenia" => "Tavo2023",
            "contrasenia_confirmation" => "Tavo2023",
            "telefono" => "096754320",
            "direccion" => "Av 112",
            "email" => "Tavo23@gmail.com",
            "rolDeLaEmpresa" => "administrador",
            "numeroDeRol" => "1"
        ];

        $response = $this->post('/api/v1/Usuarios/Crear', $datosAInsertar);

        $response->assertStatus(200);
        $response->assertJsonFragment([
            "mensaje" => "Usuario creado correctamente."
        ]);

        Usuario::where("docDeIdentidad", 45983459)->delete();
    }

    public function test_InsertarGerente()
    {
        $datosAInsertar = [
            "documentoDeIdentidad" => "56435872",
            "nombre" => "Andres",
            "apellido" => "Gomez",
            "contrasenia" => "Gomez2023",
            "contrasenia_confirmation" => "Gomez2023",
            "telefono" => "095032742",
            "direccion" => "Av 150",
            "email" => "Gomez23@gmail.com",
            "rolDeLaEmpresa" => "gerente",
            "numeroDeRol" => "1"
        ];

        $response = $this->post('/api/v1/Usuarios/Crear', $datosAInsertar);

        $response->assertStatus(200);
        $response->assertJsonFragment([
            "mensaje" => "Usuario creado correctamente."
        ]);

        Usuario::where("docDeIdentidad", 56435872)->delete();
    }

    public function test_InsertarCargador()
    {
        $datosAInsertar = [
            "documentoDeIdentidad" => "40659854",
            "nombre" => "Carlos",
            "apellido" => "juarez",
            "contrasenia" => "Sopa2023",
            "contrasenia_confirmation" => "Sopa2023",
            "telefono" => "098742561",
            "direccion" => "Av 1021",
            "email" => "Sopadu@gmail.com",
            "rolDeLaEmpresa" => "cargador",
            "numeroDeRol" => "1",
            "carnetTransporte" => "8013124"
        ];

        $response = $this->post('/api/v1/Usuarios/Crear', $datosAInsertar);

        $response->assertStatus(200);
        $response->assertJsonFragment([
            "mensaje" => "Usuario creado correctamente."
        ]);

        Usuario::where("docDeIdentidad", 40659854)->delete();
    }

    public function test_InsertarChofer()
    {
        $datosAInsertar = [
            "documentoDeIdentidad" => "67841234",
            "nombre" => "Camila",
            "apellido" => "Bonilla",
            "contrasenia" => "Chofer2023",
            "contrasenia_confirmation" => "Chofer2023",
            "telefono" => "099664081",
            "direccion" => "Av 5409",
            "email" => "Chofer23@gmail.com",
            "rolDeLaEmpresa" => "chofer",
            "numeroDeRol" => "1"
        ];

        $response = $this->post('/api/v1/Usuarios/Crear', $datosAInsertar);

        $response->assertStatus(200);
        $response->assertJsonFragment([
            "mensaje" => "Usuario creado correctamente."
        ]);

        Usuario::where("docDeIdentidad", 67841234)->delete();
    }
}
