<?php 
return [
	'path' => env('APP_PATH_LOCAL_VUE'),

]

 ?>