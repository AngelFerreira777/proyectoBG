@extends('layouts.app')

@section('content')
<!-- Main content -->
<router-view ></router-view>
<!-- /.content -->
@endsection
