<template>
	<section class="content p-2" >
		<div class="container-fluid">
			<slot></slot>
		</div>
	</section>
</template>