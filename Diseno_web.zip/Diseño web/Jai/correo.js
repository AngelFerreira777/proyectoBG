<script>
    const contactForm = document.getElementById("contactForm");
    const responseMessage = document.getElementById("responseMessage");

    contactForm.addEventListener("submit", function (e) {
        e.preventDefault(); // Evita que el formulario se envíe automáticamente

        // Obtiene los valores del formulario
        const name = document.getElementById("name").value;
        const email = document.getElementById("email").value;
        const subject = document.getElementById("subject").value;
        const message = document.getElementById("message").value;

        // Envía los datos a un servidor o realiza otras acciones aquí
        // Puedes usar AJAX o Fetch para enviar los datos a un servidor

        // Muestra un mensaje de confirmación
        responseMessage.innerHTML = "Mensaje enviado correctamente. Gracias, " + name + "!";

        // Limpia el formulario
        contactForm.reset();
    });
</script>